#include "diagram.h"
#include <defin.h>
#include <iostream>
#include <scanner.h>

using namespace std;

int
main(int argc, char* argv[])
{
  Scanner* sc;
  int type;
  Lexem l;
  if (argc <= 1)
    sc =
      new Scanner("/home/konstantin/QtProjects/Lang. and meth./src/input.txt");
  else
    sc = new Scanner(argv[1]);
  Diagram dg(sc);
  //  do {
  //    type = sc->scan(l);
  //    cout << l << " - тип " << type << endl;
  //  } while (type != LEnd);
  dg.program();

  return 0;
}
